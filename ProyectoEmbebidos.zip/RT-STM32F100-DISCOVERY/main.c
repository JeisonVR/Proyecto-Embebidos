/*
    PLAY Embedded demos - Copyright (C) 2014-2017 Rocco Marco Guglielmi

    This file is part of PLAY Embedded demos.

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See- the License for the specific language governing permissions and
    limitations under the License.
*/

/*
 *  Tested under ChibiOS 16.1.4, Project version 1.2.
 *  Please open readme.txt for changelog.
 */
 
#include "ch.h"
#include "hal.h"
#include "ch_test.h"

#include <math.h>


/*===========================================================================*/
/* ADC related code                                                          */
/*===========================================================================*/

#define ADC_NUM_CHANNELS   3
#define ADC_BUF_DEPTH      1

static adcsample_t samples[ADC_BUF_DEPTH][ADC_NUM_CHANNELS];


/*
* ADC conversion group.
* Mode:        Continuous, 1 samples of 1 channels, SW triggered.
* Channels:    IN1.
*/
static const ADCConversionGroup adcgrpcfg5 = {
  FALSE,
  ADC_NUM_CHANNELS,
  NULL,
  NULL,
  0,                                 /* CR1 */
  ADC_CR2_JEXTTRIG,                   /* CR2 */
  0,                                 /* SMPR1 */
  ADC_SMPR2_SMP_AN0(ADC_SAMPLE_1P5) |
  ADC_SMPR2_SMP_AN3(ADC_SAMPLE_1P5) |
  ADC_SMPR2_SMP_AN7(ADC_SAMPLE_1P5), /* SMPR2 */
  ADC_SQR1_NUM_CH(ADC_NUM_CHANNELS), /* SQR1 */
  0,                                 /* SQR2 */
  ADC_SQR3_SQ1_N(ADC_CHANNEL_IN0) | ADC_SQR3_SQ2_N(ADC_CHANNEL_IN3) | ADC_SQR3_SQ3_N(ADC_CHANNEL_IN7) /* SQR3 */
};
/*===========================================================================*/
/* Common functions                                                          */
/*===========================================================================*/

static void pwmpcb(PWMDriver *pwmp) {

  (void)pwmp;
  palSetPad(GPIOA, 1);
}

static void pwmc1cb(PWMDriver *pwmp) {
  (void)pwmp;
  palClearPad(GPIOA, 1);
}

static PWMConfig pwmcfg = {
  1000,                                    /* 1kHz PWM clock frequency.   */
  10000,                                    /* Initial PWM period 1S.       */
  pwmpcb,
  {
   {PWM_OUTPUT_ACTIVE_HIGH, pwmc1cb},
   {PWM_OUTPUT_DISABLED, NULL},
   {PWM_OUTPUT_DISABLED, NULL},
   {PWM_OUTPUT_DISABLED, NULL}
  },
  0,
  0,
#if STM32_PWM_USE_ADVANCED
  0
#endif
};

static void pwmpcb2(PWMDriver *pwmp) {

  (void)pwmp;
  palSetPad(GPIOA, 4);
}

static void pwmc1cb2(PWMDriver *pwmp) {

  (void)pwmp;
  palClearPad(GPIOA, 4);
}

static PWMConfig pwmcfg2 = {
  1000,                                    /* 1kHz PWM clock frequency.   */
  10000,                                    /* Initial PWM period 1S.       */
  pwmpcb2,
  {
   {PWM_OUTPUT_ACTIVE_HIGH, pwmc1cb2},
   {PWM_OUTPUT_DISABLED, NULL},
   {PWM_OUTPUT_DISABLED, NULL},
   {PWM_OUTPUT_DISABLED, NULL}
  },
  0,
  0,
#if STM32_PWM_USE_ADVANCED
  0
#endif
};

icucnt_t last_width, last_period;

static void icuwidthcb(ICUDriver *icup) {

  last_width = icuGetWidthX(icup);
}

static void icuperiodcb(ICUDriver *icup) {

  last_period = icuGetPeriodX(icup);
}

static ICUConfig icucfg = {
  ICU_INPUT_ACTIVE_HIGH,
  1000,                                    /* 10kHz ICU clock frequency.   */
  icuwidthcb,
  icuperiodcb,
  NULL,
  ICU_CHANNEL_1,
  0
};



/*===========================================================================*/
/* Blinker.                                                             */
/*===========================================================================*/



//Blinker-ADC thread
static THD_WORKING_AREA(waThd1, 256);
static THD_FUNCTION(Thd1, arg) {

  (void) arg;
  chRegSetThreadName("Blinker-ADC");
  while(TRUE) {
    palTogglePad(GPIOD,2);
    chThdSleepMilliseconds(1000);

    adcStart(&ADCD1, NULL);
    adcStartConversion(&ADCD1, &adcgrpcfg5, (adcsample_t*) samples, ADC_BUF_DEPTH);
  }
}



/*===========================================================================*/
/* PID                                                                       */
/*===========================================================================*/

int ref;
int tmp=0, tmp_ant=0 , set=0;
float P=0, I=0, D=0;
int u=0, ut=0;          // u es la salida, ut es una bandera
float bi, br, ad, bd;

float kp = 1;
float ki = 1;
float kd = 1;           //Ganancia Derivativa
float Tf = 0.05;
float Tt = 1.10;  //Tt=h/kt, con kt: Término anti-windup
float  h = 0.05;  //Tiempo de muestreo en segs.  // aumentar h para aumentar el tiempo de respuesta

int PID(int entrada, int ref){
  tmp = entrada*(1000/125);
  set = ref*(1000/15);
  bi=ki*h;
  ad=Tf/(Tf+h);
  bd=kd/(Tf+h);
  br=h/Tt;
 
  while (true){
    P=kp*(set-tmp);                           //se calcula la acción proporcional
    D=ad*D-bd*(tmp-tmp_ant);                 //se actualiza la acción derivativa
    ut=P+I+D;                                 //se calcula la salida de control

    if (ut>=1000) {                          //se aplica saturación a la salida de control
      u=1000;
    } else {
      if (ut<=0) {
        u=0;
      } else {
        u=ut;
      }
    }

    I=I+bi*(set-tmp)+br*(u-ut);               //se actualiza la acción integral
    tmp_ant=tmp;
    int salida;
    salida = u;
    return salida;
  }
} 




/*===========================================================================*/
//PID1 thread(resistencias)
/*===========================================================================*/

static THD_WORKING_AREA(waThd2, 512);
static THD_FUNCTION(Thd2, arg) {
  (void) arg;
  chRegSetThreadName("PWM1");
  while(TRUE) {

    palSetPad(GPIOA, 1);

  /*
   * Initializes the PWM driver 1 and ICU driver 4.
   */

  pwmStart(&PWMD1, &pwmcfg);
  pwmEnablePeriodicNotification(&PWMD1);
  palSetPadMode(GPIOA, 8, PAL_MODE_STM32_ALTERNATE_PUSHPULL);
  icuStart(&ICUD4, &icucfg);
  icuStartCapture(&ICUD4);
  icuEnableNotifications(&ICUD4);
  chThdSleepMilliseconds(2000);

  /*
   * Starts the PWM channel 0 using 90% duty cycle.
   */

  pwmEnableChannel(&PWMD1, 0, PWM_PERCENTAGE_TO_WIDTH(&PWMD1, PID(samples[0][0], samples[0][2]*(150/4095))));
  pwmEnableChannelNotification(&PWMD1, 0);
  chThdSleepMilliseconds(5000);

  /*

  pwmChangePeriod(&PWMD1, 1000);
  chThdSleepMilliseconds(5000);
  */
  /*
   * Disables channel 0 and stops the drivers.
   */
  
  pwmDisableChannel(&PWMD1, 0);
  pwmStop(&PWMD1);
  icuStopCapture(&ICUD4);
  icuStop(&ICUD4);
  palSetPad(GPIOA, 1);
    
  }
}


//PWM2 thread (ventilador)

static THD_WORKING_AREA(waThd3, 512);
static THD_FUNCTION(Thd3, arg) {
  (void) arg;
  chRegSetThreadName("PWM2");
  while(TRUE) {

    palSetPad(GPIOA, 4);
    
/*
   * Initializes the PWM driver 2 and ICU driver 4.
   */
  
  pwmStart(&PWMD3, &pwmcfg2);
  pwmEnablePeriodicNotification(&PWMD3);
  palSetPadMode(GPIOA, 9, PAL_MODE_STM32_ALTERNATE_PUSHPULL);
  icuStart(&ICUD4, &icucfg);
  icuStartCapture(&ICUD4);
  icuEnableNotifications(&ICUD4);
  chThdSleepMilliseconds(2000);
  
  /*
   * Starts the PWM channel 0 using 90% duty cycle.
   */
  
  pwmEnableChannel(&PWMD3, 0, PWM_PERCENTAGE_TO_WIDTH(&PWMD3, 1000-PID(samples[0][0], samples[0][2]*(150/4095))));
  pwmEnableChannelNotification(&PWMD3, 0);
  chThdSleepMilliseconds(5000);
  /*
  pwmChangePeriod(&PWMD3, 1000);
  chThdSleepMilliseconds(5000);
  */
  /*
   * Disables channel 0 and stops the drivers.
   */
  
  pwmDisableChannel(&PWMD3, 0);
  pwmStop(&PWMD3);
  icuStopCapture(&ICUD4);
  icuStop(&ICUD4);
  palSetPad(GPIOA, 4);
  
  }
}


/*
 * Application entry point.
 */
int main(void) {

  /*
   * System initializations.
   * - HAL initialization, this also initializes the configured device drivers
   *   and performs the board-specific initializations.
   * - Kernel initialization, the main() function becomes a thread and the
   *   RTOS is active.
   */
  halInit();
  chSysInit();
  boardInit();
  /*
   * Activates the serial driver 2 using the driver default configuration.
   */
  
  /*
   * Setting up analog inputs used by the demo.
   */
  palSetPadMode(GPIOA, 0, PAL_MODE_INPUT_ANALOG);
  palSetPadMode(GPIOA, 3, PAL_MODE_INPUT_ANALOG);
  palSetPadMode(GPIOA, 7, PAL_MODE_INPUT_ANALOG);
  palSetPad(GPIOA, 1);
  palSetPad(GPIOA, 4);
  sdStart(&SD3 , NULL);  

  BaseSequentialStream * chp = (BaseSequentialStream *) &SD3;

  chThdCreateStatic(waThd1, sizeof(waThd1), NORMALPRIO + 1, Thd1, NULL);
  chThdCreateStatic(waThd2, sizeof(waThd2), NORMALPRIO + 1, Thd2, NULL);
  chThdCreateStatic(waThd3, sizeof(waThd3), NORMALPRIO + 1, Thd3, NULL);
  /*
   * Normal main() thread activity, in this demo it checks flag status. If flag
   * is true, last value is printed and then flag is lowered. If error is true
   * an error message is printed.
   */

   while (TRUE) {

    //chprintf(chp, "%u,%u,%u\r\n", samples[0][0], PID(samples[0][0], ref), 10000-PID(samples[0][0], ref));
    chprintf(chp, "%u,%u*%u\n", samples[0][0], samples[0][1], samples[0][2]);
    chThdSleepMilliseconds(100);
  }
}